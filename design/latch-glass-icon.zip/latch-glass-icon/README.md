# Latch — Cobalt clasp, Glass

Source color: #145CFF. Rendered through Icon Composer MCP 1.1.0 and Apple ictool 27.0.

- Latch.icon: editable Apple Icon Composer document.
- source/clasp.svg: editable foreground vector.
- source/flat-icon.svg: flat vector for browser use.
- macos/: four native appearances (default, dark, clear light, clear dark) at 1024 px; default PNG sizes from 16 to 1024 px; Latch.icns and Latch.iconset.
- chrome/: flat PNG icons at 16, 32, 48, and 128 px for toolbar clarity.
- preview.png: appearance comparison sheet.

The system material can change the visible blue from the source color. The .icon document supports native appearances; legacy .icns uses the default appearance. Assets are prepared, not installed.
